"""Lightweight private chat application."""

